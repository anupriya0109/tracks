sap.ui.define(["sap/ovp/app/Component"], function(AppComponent) {
    return AppComponent.extend("ovp.tracksovp.Component", {
        metadata: {
            manifest: "json"
        }
    });
});
